3D CSS cubes
=====

A very simple interactive grid in 3d space. Click to drag and rotate the view, add cubes of different colors, and play around.

Nothing to set up -- just open up `index.html` and you're set!

3D effects are pure CSS.

----
